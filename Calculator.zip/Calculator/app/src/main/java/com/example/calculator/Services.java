package com.example.calculator;

public class Services {
    private double nb1;
    private double nb2;

    public Services(double nb1, double nb2) {
        this.nb1 = nb1;
        this.nb2 = nb2;
    }

    public double add(){
        return this.nb1+this.nb2;
    }
    public double div(){
        if (this.nb2 != 0){
            return this.nb1/this.nb2;
        }else{
            return 0;
        }

    }
    public double sub(){
        return this.nb1-this.nb2;
    }
    public double multi(){
        return this.nb1*this.nb2;
    }
}
