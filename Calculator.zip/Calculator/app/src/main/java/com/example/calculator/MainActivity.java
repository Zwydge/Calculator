package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView result = findViewById(R.id.result);
        final TextView tapping = findViewById(R.id.tapping);

        Button one = findViewById(R.id.one);
        Button two = findViewById(R.id.two);
        Button three = findViewById(R.id.three);
        Button four = findViewById(R.id.four);
        Button five = findViewById(R.id.five);
        Button six = findViewById(R.id.six);
        Button seven = findViewById(R.id.seven);
        Button eight = findViewById(R.id.eight);
        Button nine = findViewById(R.id.nine);
        Button zero = findViewById(R.id.zero);

        Button add = findViewById(R.id.add);
        Button multi = findViewById(R.id.multi);
        Button sub = findViewById(R.id.moins);
        Button div = findViewById(R.id.div);
        Button equal = findViewById(R.id.equal);
        Button del = findViewById(R.id.del);
        Button decim = findViewById(R.id.decim);
        Button cancel = findViewById(R.id.cancel);

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"1");
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"2");
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"3");
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"4");
            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"5");
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"6");
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"7");
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"8");
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"9");
            }
        });
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"0");
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"+");
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"-");
            }
        });
        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"x");
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                tapping.setText(current+"/");
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String current = (String) tapping.getText();
                if (current != null && current.length() > 0) {
                    current = current.substring(0, current.length() - 1);
                }
                tapping.setText(current);
            }
        });
        decim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = (String) tapping.getText();
                if (!current.contains(".")){
                    if (current.equals("")){
                    }else{
                        tapping.setText(current+".");
                    }
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tapping.setText("");
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String calcul = (String) tapping.getText();
                if (calcul.contains("+")){
                    String[] separated = calcul.split("\\+");
                    double nb1 = Double.parseDouble(separated[0].trim());
                    separated[1] = separated[1].trim();
                    double nb2 = Double.parseDouble(separated[1]);
                    Services service = new Services(nb1, nb2);
                    double resultnb = (double) service.add();
                    result.setText(Integer.toString((int) resultnb));
                    tapping.setText("");
                }
                else if (calcul.contains("-")){
                    String[] separated = calcul.split("-");
                    double nb1 = Double.parseDouble(separated[0]);
                    separated[1] = separated[1].trim();
                    double nb2 = Double.parseDouble(separated[1]);
                    Services service = new Services(nb1, nb2);
                    double resultnb = (double) service.sub();
                    result.setText(Integer.toString((int) resultnb));
                    tapping.setText("");
                }
                else if (calcul.contains("x")){
                    String[] separated = calcul.split("x");
                    double nb1 = Double.parseDouble(separated[0]);
                    separated[1] = separated[1].trim();
                    double nb2 = Double.parseDouble(separated[1]);
                    Services service = new Services(nb1, nb2);
                    double resultnb = (double) service.multi();
                    result.setText(Integer.toString((int) resultnb));
                    tapping.setText("");
                }
                else if (calcul.contains("/")){
                    String[] separated = calcul.split("/");
                    double nb1 = Double.parseDouble(separated[0]);
                    separated[1] = separated[1].trim();
                    double nb2 = Double.parseDouble(separated[1]);
                    Services service = new Services(nb1, nb2);
                    double resultnb = (double) service.div();
                    result.setText(Integer.toString((int) resultnb));
                    tapping.setText("");
                }
                else{
                    result.setText("0");
                }
            }
        });

    }

}

